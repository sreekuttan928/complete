package com.wal.market.product.exception;

public class WalMarketException extends Exception {

	private static final long serialVersionUID = 1L;

	public WalMarketException(String message) {
		super(message);
	}

}
